 
package principal;
import gestionBD.AsistenteBD;
public class Principal {
    
    public static void main(String[] args) {
        AsistenteBD abd = new AsistenteBD();
        
        
        abd.CrearTabla();
//        abd.crearBD();
        
    }
    
}
